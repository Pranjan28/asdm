package com.app.core;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestGoogle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String driverPath="F:\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", driverPath);		
		WebDriver myDriver=new ChromeDriver();
		myDriver.manage().window().maximize();
		myDriver.get("https://facebook.com");
//		myDriver.findElement(By.name("q")).sendKeys("https://facebook.com");
//		myDriver.findElement(By.name("btnK")).submit();
		System.out.println(myDriver.getTitle());
		myDriver.findElement(By.id("u_0_b")).click();
		myDriver.findElement(By.id("email")).sendKeys("ash.chopkar@gmail.com");
		myDriver.findElement(By.id("pass")).sendKeys("9405121907");
		myDriver.findElement(By.id("loginbutton")).submit();
		
		
		  //myDriver.findElement(By.id("userNavigationLabel")).click();
		myDriver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		  myDriver.findElement(By.name("q")).sendKeys("pranav dhanvij");
		  myDriver.findElement(By.className("_42ft _4jy0 _4w98 _4jy3 _517h _51sy _4w97")).click();
		 // myDriver.findElement(By.id("pageLoginAnchor")).click();
		  
		  // driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		  
		  myDriver.findElement(By.partialLinkText("Log Out")).click();
		  
		  System.out.println("Log out");
		 
	}

}
