package com.app.core;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class TestFB {

	String driverPath = "F:\\geckodriver.exe";
	public WebDriver driver;

	@Before
	public void startBrowser() {
		System.setProperty("webdriver.gecho.driver", driverPath);

		/*
		 * DesiredCapabilities capabilities= DesiredCapabilities.firefox();
		 * capabilities.setCapability("marionette", true); driver = new
		 * FirefoxDriver(capabilities);
		 */

		FirefoxOptions options = new FirefoxOptions();
		options.setCapability("marionette", true);
		driver = new FirefoxDriver(options);
	}

	

	@Test
	public void navigateToUrl() {
		driver.get("https://www.facebook.com");
		System.out.println(driver.getTitle());
		driver.findElement(By.id("u_0_b")).click();
		driver.findElement(By.id("email")).sendKeys("ash.chopkar@gmail.com");
		driver.findElement(By.id("pass")).sendKeys("9405121907");
		driver.findElement(By.id("loginbutton")).submit();
		
		//driver.findElement(By.id("userNavigationLabel")).click();
		
		
		  driver.findElement(By.id("pageLoginAnchor")).click();
		  
		  // driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		  
		  driver.findElement(By.partialLinkText("Log Out")).click();
		  
		  System.out.println("Log out");
		 
	}
	@After
	public void shutDown() throws Exception {
	
		wait(1000);
		driver.close();
	}

}
