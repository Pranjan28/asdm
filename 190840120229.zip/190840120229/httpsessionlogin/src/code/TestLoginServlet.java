package code;

import static org.junit.Assert.*;

import java.io.IOException;

import javax.servlet.ServletException;

import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

public class TestLoginServlet {

	private LoginServlet myServlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;

	@Before
	public void setUp() {
		myServlet = new LoginServlet();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
	}

	@Test
	public void testDoPostHttpServletRequestHttpServletResponse() throws ServletException, IOException {
//		fail("Not yet implemented");
		request.addParameter("password", "admin123");

		myServlet.doPost(request, response);
		assertFalse(response.getContentAsString().equals("Sorry, username or password error!"));		
		assertFalse(!response.getContentAsString().equals("Sorry, username or password error!"));
	}

}
